
int read_float (float *pnum, FILE * hd);
