The PathTool utility is contributed by Luke Bailey <luke@psychoanalyse.co.uk>
and was retrieved from the URL "http://www.digievo.co.uk/software.asp".

