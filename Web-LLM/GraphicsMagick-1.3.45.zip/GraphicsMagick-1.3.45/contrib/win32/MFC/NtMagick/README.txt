NtMagick is an ImageMagick and Magick++ sample apple written in MFC that
shows how to use MFC and ImageMagick together. It is meant as a starting
point only. It creates a GUI that supports loading and displaying and
image, as well as rotating it.

The author of NtMagick is Robert Bennett <rbennett@iinet.net.au> or
<rbennett@au1.ibm.com>

1.00  Original Release
1.01  Modified to automatic allocation of images
