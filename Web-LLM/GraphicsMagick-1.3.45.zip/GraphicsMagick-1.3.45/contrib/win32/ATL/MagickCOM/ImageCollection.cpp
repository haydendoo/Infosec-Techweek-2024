// ImageCollection.cpp : Implementation of CImageCollection
#include "stdafx.h"
#include "MagickCOM.h"
#include "ImageCollection.h"

/////////////////////////////////////////////////////////////////////////////
// CImageCollection

