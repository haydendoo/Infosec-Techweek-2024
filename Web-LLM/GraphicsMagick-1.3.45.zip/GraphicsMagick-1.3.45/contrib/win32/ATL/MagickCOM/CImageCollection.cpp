// CImageCollection
#include "CImageCollection.h"
