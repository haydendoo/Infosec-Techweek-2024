======================
GraphicsMagick for iOS
======================

The associated 'mkmagick' script is Claudio Marforio's (marforio AT
gmail.com) imagemagick_compile.sh modified by Vladimir Moushkov
(vl.moushkov AT gmail.com) to build GraphicsMagick for iOS (as runs on
the iPhone and iPad) rather than ImageMagick.

According to Vladimir, GraphicsMagick runs quite a lot faster on the
iPhone than ImageMagick does.

Claudio's Blog post about ImageMagick on iOS may be found at
"http://www.cloudgoessocial.net/2011/03/21/im-xcode4-ios4-3/" and the
source code may be retrieved via git from
"https://github.com/marforic/imagemagick_lib_iphone".
