This directory is to contain any design notes regarding the
implementation of GraphicsMagick.
